project('gtk-session-lock',
    ['c'],
    version: '0.2.0',
    license: 'GPLv3',
    meson_version: '>=0.45.1',
    default_options: ['c_std=gnu11', 'warning_level=3'])

lib_so_version = '0'

add_project_arguments(
    ['-Wno-pedantic', '-Werror=unused-function', '-fvisibility=hidden'],
    language: 'c')

gtk = dependency('gtk+-3.0', version: '>=3.22.0')
wayland_client = dependency('wayland-client', version: '>=1.10.0')

# only required for the tests
wayland_server = dependency('wayland-server', version: '>=1.10.0', required: false)

# wayland_scanner is required, but we can find it without pkg-config
wayland_scanner = dependency('wayland-scanner', version: '>=1.10.0', required: false, native: true)

# use system xdg-shell protocol when available
wayland_protocols = dependency('wayland-protocols', version: '>=1.16', required: false)

pkg_config = import('pkgconfig')
gnome = import('gnome')

subdir('include')
subdir('protocol')
subdir('gtk-priv')
subdir('src')

gtk_session_lock = declare_dependency(
    link_with: gtk_session_lock_lib,
    include_directories: gtk_session_lock_inc)

subdir('examples')

if get_option('tests')
    subdir('test')
endif
